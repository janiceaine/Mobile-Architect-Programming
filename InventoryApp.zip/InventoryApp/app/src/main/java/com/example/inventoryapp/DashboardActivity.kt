package com.example.inventoryapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private lateinit var rvInventory: RecyclerView
    private lateinit var etItemName: EditText
    private lateinit var etItemQuantity: EditText
    private lateinit var btnAddItem: Button
    private lateinit var btnUpdateItem: Button
    private lateinit var btnDeleteItem: Button

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var adapter: InventoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_inventory)  // Replace with the correct layout name

        // Initialize UI elements
        rvInventory = findViewById(R.id.rvInventory)
        etItemName = findViewById(R.id.etItemName)
        etItemQuantity = findViewById(R.id.etItemQuantity)
        btnAddItem = findViewById(R.id.btnAddItem)
        btnUpdateItem = findViewById(R.id.btnUpdateItem)
        btnDeleteItem = findViewById(R.id.btnDeleteItem)

        // Initialize DatabaseHelper
        databaseHelper = DatabaseHelper(this)

        // Set up RecyclerView
        rvInventory.layoutManager = LinearLayoutManager(this)

        // Initialize adapter with mutable list
        adapter = InventoryAdapter(databaseHelper.getInventoryList().toMutableList(), databaseHelper) {
            adapter.updateItems(databaseHelper.getInventoryList().toMutableList())
        }

        rvInventory.adapter = adapter

        // Add item to inventory
        btnAddItem.setOnClickListener {
            val itemName = etItemName.text.toString().trim()
            val itemQuantity = etItemQuantity.text.toString().trim().toIntOrNull()

            if (itemName.isEmpty() || itemQuantity == null) {
                Toast.makeText(this, "Please enter valid item details", Toast.LENGTH_SHORT).show()
            } else {
                val result = databaseHelper.addInventoryItem(itemName, itemQuantity)
                if (result == -1L) {
                    Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show()
                } else {
                    adapter.updateItems(databaseHelper.getInventoryList().toMutableList())  // Update inventory list
                    clearInputs()
                    Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Update item in inventory
        btnUpdateItem.setOnClickListener {
            val itemName = etItemName.text.toString().trim()
            val itemQuantity = etItemQuantity.text.toString().trim().toIntOrNull()

            if (itemName.isEmpty() || itemQuantity == null) {
                Toast.makeText(this, "Please enter valid item details", Toast.LENGTH_SHORT).show()
            } else {
                val itemId = databaseHelper.getItemIdByName(itemName)
                if (itemId != null) {
                    val success = databaseHelper.updateInventoryItem(itemId, itemName, itemQuantity)
                    if (success > 0) {
                        adapter.updateItems(databaseHelper.getInventoryList().toMutableList())
                        clearInputs()
                        Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Delete item from inventory
        btnDeleteItem.setOnClickListener {
            val itemName = etItemName.text.toString().trim()

            if (itemName.isEmpty()) {
                Toast.makeText(this, "Enter item name to delete", Toast.LENGTH_SHORT).show()
            } else {
                val itemId = databaseHelper.getItemIdByName(itemName)
                if (itemId != null) {
                    val success = databaseHelper.deleteInventoryItem(itemId)
                    if (success > 0) {
                        adapter.updateItems(databaseHelper.getInventoryList().toMutableList())
                        clearInputs()
                        Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearInputs() {
        etItemName.text.clear()
        etItemQuantity.text.clear()
    }
}