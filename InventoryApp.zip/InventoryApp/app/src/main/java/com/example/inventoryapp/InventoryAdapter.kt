package com.example.inventoryapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private var itemList: MutableList<InventoryItem>, // Mutable list to allow modification
    private val dbHelper: DatabaseHelper,
    private val refreshList: () -> Unit
) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

    // ViewHolder class to hold references to UI elements
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvItemName: TextView = itemView.findViewById(R.id.tvItemName)
        val tvItemQuantity: TextView = itemView.findViewById(R.id.tvItemQuantity)
        val btnDelete: Button = itemView.findViewById(R.id.btnDelete)
        val btnEdit: Button = itemView.findViewById(R.id.btnEdit) // Add this reference
    }

    // Update the list of items and notify the adapter that the data has changed
    fun updateItems(newItems: MutableList<InventoryItem>) {
        itemList = newItems  // Update the list of items
        notifyDataSetChanged()  // Notify the adapter that the data has changed
    }

    // Create a new view holder for each item in the list
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.inventory_item, parent, false)
        return ViewHolder(view)
    }

    // Bind data to the views in the view holder
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = itemList[position]
        holder.tvItemName.text = item.name
        holder.tvItemQuantity.text = String.format(holder.itemView.context.getString(R.string.qty_format), item.quantity)

        // Edit Item
        holder.btnEdit.setOnClickListener {
            val context = holder.itemView.context
            val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_add_item, null)
            val etItemName = dialogView.findViewById<EditText>(R.id.etItemName)
            val etItemQuantity = dialogView.findViewById<EditText>(R.id.etItemQuantity)

            // Set the current item details to the EditText fields
            etItemName.setText(item.name)
            etItemQuantity.setText(item.quantity.toString())

            // Show the dialog to edit item
            AlertDialog.Builder(context)
                .setTitle("Edit Inventory Item")
                .setView(dialogView)
                .setPositiveButton("Update") { _, _ ->
                    val newName = etItemName.text.toString()
                    val newQuantity = etItemQuantity.text.toString().toIntOrNull() ?: 0

                    if (newName.isNotEmpty()) {
                        // Update the item in the database and refresh the list
                        dbHelper.updateInventoryItem(item.id, newName, newQuantity)
                        refreshList()
                        Toast.makeText(context, "Item Updated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Enter a valid name", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Delete Item
        holder.btnDelete.setOnClickListener {
            dbHelper.deleteInventoryItem(item.id)
            refreshList() // Refresh the list after deletion
            Toast.makeText(holder.itemView.context, "Item Deleted!", Toast.LENGTH_SHORT).show()
        }
    }

    // Return the total number of items in the list
    override fun getItemCount(): Int = itemList.size
}
