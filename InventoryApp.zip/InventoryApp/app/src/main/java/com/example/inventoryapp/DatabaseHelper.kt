package com.example.inventoryapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "InventoryDB"
        private const val DATABASE_VERSION = 1
        private const val TABLE_INVENTORY = "inventory"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_QUANTITY = "quantity"
    }

    // Called when the database is created (initial setup)
    override fun onCreate(db: SQLiteDatabase) {
        // Create the inventory table
        val createTable = """
            CREATE TABLE $TABLE_INVENTORY (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, 
                $COLUMN_NAME TEXT, 
                $COLUMN_QUANTITY INTEGER
            )
        """
        db.execSQL(createTable)
    }

    // Called when the database is upgraded (not needed in this case)
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INVENTORY")
        onCreate(db)
    }

    // Insert a new item into the inventory
    fun addInventoryItem(name: String, quantity: Int): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_QUANTITY, quantity)
        }
        val result = db.insert(TABLE_INVENTORY, null, values)
        db.close()
        return result
    }

    // Get all inventory items as a list
    fun getInventoryList(): List<InventoryItem> {
        val inventoryList = mutableListOf<InventoryItem>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
                val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY))
                inventoryList.add(InventoryItem(id, name, quantity))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return inventoryList
    }

    // Get an item ID by its name
    fun getItemIdByName(name: String): Int? {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT $COLUMN_ID FROM $TABLE_INVENTORY WHERE $COLUMN_NAME = ?", arrayOf(name))
        var itemId: Int? = null
        if (cursor.moveToFirst()) {
            itemId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
        }
        cursor.close()
        db.close()
        return itemId
    }

    // Update an existing inventory item
    fun updateInventoryItem(id: Int, name: String, quantity: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_QUANTITY, quantity)
        }
        val result = db.update(TABLE_INVENTORY, values, "$COLUMN_ID = ?", arrayOf(id.toString()))
        db.close()
        return result
    }

    // Delete an inventory item by its ID
    fun deleteInventoryItem(id: Int): Int {
        val db = this.writableDatabase
        val result = db.delete(TABLE_INVENTORY, "$COLUMN_ID = ?", arrayOf(id.toString()))
        db.close()
        return result
    }
}
