package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class EditItemActivity : AppCompatActivity() {

    private lateinit var etItemName: EditText
    private lateinit var etItemQuantity: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button
    private lateinit var databaseHelper: DatabaseHelper
    private var itemId: Int = -1  // Stores the item ID

    fun updateItem() {
        // Function logic to update the item
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_item)

        // Initialize UI components
        etItemName = findViewById(R.id.etItemName)
        etItemQuantity = findViewById(R.id.etItemQuantity)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
        databaseHelper = DatabaseHelper(this)

        // Retrieve item details from intent
        itemId = intent.getIntExtra("ITEM_ID", -1)
        val itemName = intent.getStringExtra("ITEM_NAME") ?: ""
        val itemQuantity = intent.getIntExtra("ITEM_QUANTITY", 0)

        // Pre-fill input fields with existing values
        etItemName.setText(itemName)
        etItemQuantity.setText(itemQuantity.toString())

        // Save button updates item in the database
        btnSave.setOnClickListener {
            val updatedName = etItemName.text.toString().trim()
            val updatedQuantity = etItemQuantity.text.toString().toIntOrNull()

            if (updatedName.isEmpty() || updatedQuantity == null) {
                Toast.makeText(this, "Please enter valid values", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val updatedItem = InventoryItem(itemId, updatedName, updatedQuantity)
            databaseHelper.updateItem(updatedItem)

            Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }

        // Cancel button returns to Dashboard without saving
        btnCancel.setOnClickListener {
            finish()
        }
    }
}

private fun DatabaseHelper.updateItem(updatedItem: InventoryItem) {

}
